package org.fasttrackit;

public class DemoShop {
    public static final String HOMEPAGE_URL = "https://fasttrackit-test.netlify.app/#/";

    public static void main(String[] args) {
        Page demoShopPage = new Page();
        demoShopPage.openPage();

        Header header = new Header();
        String greetingsMSG = header.getGreetingsMsg();

        System.out.println("'" + greetingsMSG + "' message is displayed in header");
        header.clickOnTheLoginIcon();

        Modal loginModal= new Modal();
        loginModal.clickOnTheUsernameField();

        String username = "dino";
        loginModal.typeInUserName(username);

        loginModal.clickOnThePasswordField();
        String password = "choochoo";
        loginModal.typeInPassword(password);

       loginModal.clickOnTheLoginButton();

        String greetingMSG = "Hi,dino!";
        System.out.println("Expected result: '" + greetingMSG + "' messaged is displayed in header");

    }



}