package org.fasttrackit;

import com.codeborne.selenide.Selenide;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static java.lang.Thread.sleep;

public class PcTestingSorting {

    private static Page page;

    @BeforeClass
    public static void setUp() throws InterruptedException {
        Selenide.open("https://fasttrackit-test.netlify.app/#/");
        page = new Page();
        sleep(2000);
    }

    @Test
    public void testSortByPriceHighToLow() throws InterruptedException {
        page.selectSortOption("Sort by price (high to low)");
    }

    @Test
    public void testSortByPriceLowToHigh() throws InterruptedException {
        page.selectSortOption("Sort by price (low to high)");
    }

    @Test
    public void testSortByNameAToZ() throws InterruptedException {
        page.selectSortOption("Sort by name (A to Z)");
    }

    @Test
    public void testSortByNameZToA() throws InterruptedException {
        page.selectSortOption("Sort by name (Z to A)");
    }
}

// This only test the functionality of the sorting drop down list, and the fact that every option is clickable.