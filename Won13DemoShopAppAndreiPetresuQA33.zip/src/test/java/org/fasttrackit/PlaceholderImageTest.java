package org.fasttrackit;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.CollectionCondition;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.annotations.Parameters;

import static com.codeborne.selenide.Selenide.$$;

public class PlaceholderImageTest {

    @BeforeTest
    public static void openWebsite() {
        Selenide.open("https://fasttrackit-test.netlify.app/#/");
    }

    @Test(dataProvider = "productIndices")
    @Parameters("productIndex")
    public void testImageExistsForProduct(int productIndex) {
        ElementsCollection productElement = $$("#root > div > div:nth-child(2) > div:nth-child(2) > div.row.row-cols-xl-4.row-cols-lg-3.row-cols-md-2.row-cols-sm-2.row-cols-1 > div:nth-child(" + productIndex + ") > div");

        ElementsCollection imgElements = productElement.get(0).$$("img");

        imgElements.shouldHave(CollectionCondition.sizeGreaterThan(0));
    }

    @org.testng.annotations.DataProvider(name = "productIndices")
    public Object[][] productIndices() {
        return new Object[][]{
                {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}, {9}, {10}, {11}, {12}
        };
    }
}