package org.fasttrackit;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.Selenide;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;

import static com.codeborne.selenide.Selenide.*;
import static org.testng.Assert.assertTrue;

public class PlaceholderPricesTest{

    @BeforeClass
    public void openWebsite() {
        Selenide.open("https://fasttrackit-test.netlify.app/#/");
    }

    @Test(dataProvider = "productIndices")
    public void testNumericalPriceForProduct(int productIndex) {
        ElementsCollection productElement = $$("#root > div > div:nth-child(2) > div:nth-child(2) > " +
                "div.row.row-cols-xl-4.row-cols-lg-3.row-cols-md-2.row-cols-sm-2.row-cols-1 > div:nth-child(" + productIndex + ") > div");

        ElementsCollection priceElements = productElement.get(0).$$(".text-muted.text-center.card-footer > p:nth-child(1)");

        assertTrue(priceElements.texts().get(0).matches("\\$?\\d+(\\.\\d+)?"));
    }

    @DataProvider(name = "productIndices")
    public Object[][] getProductIndices() {
        return new Object[][] {
                {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}, {9}, {10}, {11}, {12}
        };
    }
}