package org.fasttrackit;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.WebDriverRunner;
import org.testng.annotations.Test;
import static com.codeborne.selenide.Selenide.*;
import static org.testng.Assert.assertEquals;

public class WishListTest {



    @Test
    public void testIconClickNavigatesToCorrectPath() {
        Selenide.open("https://fasttrackit-test.netlify.app/#/");

        $("#responsive-navbar-nav > div:nth-child(2) > span > a:nth-child(2) > svg > path").click();

        String expectedPath = "https://fasttrackit-test.netlify.app/#/wishlist";

        Selenide.Wait().until(driver -> driver.getCurrentUrl().equals(expectedPath));

        assertEquals(expectedPath, WebDriverRunner.url(), "Icon click did not navigate to the correct path");
    }

    @Test
    public void testMessageIsDisplayed() {
        $("#root > div > div:nth-child(2)").shouldHave(Condition.text("How about you add some products to cart?"));
    }
}
